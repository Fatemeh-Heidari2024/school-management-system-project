import exception.PasswordFormatProblemException;
import exception.UsernameFormatProblemException;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) throws DateTimeParseException, UsernameFormatProblemException, PasswordFormatProblemException {
        java.util.Scanner input = new Scanner(System.in);
        //Add student
        //try {
            System.out.println("Enter username");
            String username = input.next();
            if (username.length() < 8)
                throw new UsernameFormatProblemException("you enter:" + username.length() + "character");
        //} catch (UsernameFormatProblemException e) {
//            UsernameFormatProblemException("you enter:" + username.length() + "character");
//            while (input.next().length() < 8) {
//                System.out.println("Enter correct username: ");
//                String username = input.next();
//                if(username.length()>=8) break;
//            }


       // try {
            System.out.println("Enter password");
            String password = input.next();
            if (password.length() < 8)
                throw new PasswordFormatProblemException("you enter:" + password.length() + "character");
//        } catch (PasswordFormatProblemException e) {
//
//            while (input.next().length() < 8) {
//                System.out.println("Enter correct password: ");
//                String username = input.next();
//                if(username.length()>=8) break;
//            }
//        }
        
        System.out.println("Enter student_id:");
        int id = input.nextInt();
        System.out.println("Enter first name:");
        String firstName = input.next();
        System.out.println("Enter last name:");
        String lastName = input.next();
        System.out.println("Enter nationalCode:");
        String nationalCode = input.next();
        System.out.println("Enter entry date");
        String entryDate = input.next();
        LocalDate entry = LocalDate.parse(entryDate);

        System.out.println("Enter date of birth");
        String dob = input.next();
        LocalDate dobDate = LocalDate.parse(dob);


        System.out.println("Enter gpu");
        double gpu = input.nextDouble();



    }
}