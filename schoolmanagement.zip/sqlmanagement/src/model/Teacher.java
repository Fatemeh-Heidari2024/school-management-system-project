package model;

import java.time.LocalDate;

public class Teacher extends User{
    public Teacher(long id, String firstName, String lastName, String nationalCode, LocalDate dataOfBirth, LocalDate entryDate, String username, String password) {
        super(id, firstName, lastName, nationalCode, dataOfBirth, entryDate, username, password);
    }

}
