package model;

import java.time.LocalDate;

public class User extends BaseEntity{
    private String firstName;
    private String lastName;
    private String nationalCode;
    private LocalDate dataOfBirth;
    private LocalDate entryDate;
    private String username;
    private String password;


    public User(long id, String firstName, String lastName, String nationalCode, LocalDate dataOfBirth, LocalDate entryDate, String username, String password) {
        super(id);
        this.firstName = firstName;
        this.lastName = lastName;
        this.nationalCode = nationalCode;
        this.dataOfBirth = dataOfBirth;
        this.entryDate = entryDate;
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNationalCode() {
        return nationalCode;
    }

    public void setNationalCode(String nationalCode) {
        this.nationalCode = nationalCode;
    }

    public LocalDate getDataOfBirth() {
        return dataOfBirth;
    }

    public void setDataOfBirth(LocalDate dataOfBirth) {
        this.dataOfBirth = dataOfBirth;
    }

    public LocalDate getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    @Override
    public String toString() {
        return "User{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", nationalCode='" + nationalCode + '\'' +
                ", dataOfBirth=" + dataOfBirth +
                ", entryDate=" + entryDate +
                ", username='" + username + '\'' +
                '}';
    }
}
