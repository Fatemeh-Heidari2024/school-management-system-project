package model;

import java.time.LocalDate;

public class Student extends User {
    private double gpu;

    public Student(long id, String firstName, String lastName, String nationalCode, LocalDate dataOfBirth, LocalDate entryDate,double gpu, String username, String password) {
        super(id, firstName, lastName, nationalCode, dataOfBirth, entryDate, username, password);
        this.gpu=gpu;
    }


    @Override
    public String toString() {
        return "Student{" +
                "gpu=" + gpu +
                '}';
    }
}

